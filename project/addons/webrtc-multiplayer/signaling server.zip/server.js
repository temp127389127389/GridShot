const Websocket = require("ws")
const crypto = require("crypto")

const PORT = process.env.PORT || 8080


// the below only includes packet types used by the signaling server
// the game instances have a more extensive list of packet types
const PacketTypes = {
	PeerAssignedID : 0,
	DeclareLobbyHost : 1,
}

// Num doesn't contain 0 since player peer ids are type Number, which means
// that id = 0123 is the same as id = 123. This change is to preserve id length
const NUM = "123456789".split("")
const PEER_ID_LEN = 8

class Peer {
    /**
     * @param {number} peer_id
     * @param {Websocket} ws
     */
    constructor(peer_id, ws) {
        this.id = peer_id
        this.ws = ws

        // The "mail distribution center", aka the Peers instance, handles websocket events
        ws.onmessage = peers.receive.bind(peers)
        ws.onclose = (_event) => {peers.remove_peer(this.id)}
    }
}

/**
 * A Peers instance resembles a mail distribution center (refered to as MDC below).
 * Packets come in and if they have a json structure and a valid address that the MDC
 *     knows then the packet is forwarded to that address only if the packet destination
 *     isn't the MDC
 */
class Peers {
    constructor() {
        this.player_peers = new Map // Map[Number, Peer]
        this.lobby_peers = new Map  // Map[String, Peer]
    }

    /**
     * Add a new Peer instance to player_peers with the given websocket and
     * send the assigned peer_id to the other end of the websocket connection
     * @param {Websocket} ws
     */
    add_peer(ws) {
        var peer_id = this.gen_player_peer_id()
        console.log("added peer with id " + peer_id)

        this.player_peers.set(peer_id, new Peer(peer_id, ws))
        this.send(PacketTypes.PeerAssignedID, peer_id)
    }

    /**
     * Remove a peer from either lobby_peers or player_peer, depending on
     * wether the type of peer_id is string or not
     * @param {number | string} peer_id
     */
    remove_peer(peer_id) {
        console.log("removing peer " + peer_id)
        if (typeof(peer_id) == "string") {this.player_peers.delete(peer_id)}
        else {this.lobby_peers.delete(peer_id)}
    }

    /**
     * Return the Peer object corresponding to the given peer_id or undefined,
     * depending on wether a Peer was found
     * @param {number | string} peer_id
     * @returns {undefined | Peer}
     */
    get_peer(peer_id) {
        if (typeof(peer_id) == "string") {return this.lobby_peers.get(peer_id)}
        else {return this.player_peers.get(peer_id)}
    }

    /**
     * Send a packet through the websocket connection of the Peer object
     * corresponding to dst. dst is used as a peer id. The packet will contain
     * a type, dst and src key-value pair as well as everything in the data
     * argument
     * @param {number} type
     * @param {number | string} dst
     * @param {JSON} data
     */
    send(type, dst, data = {}) {
        console.log("sending packet to " + dst)
        var dst_peer = this.get_peer(dst)
        if (dst_peer != undefined) {
            var formatted_data_json = Object.assign({}, {"type": type, "dst": dst, "src": -1}, data)
            dst_peer.ws.send(JSON.stringify(formatted_data_json))
        }
    }

    /**
     * This is called whenever a websocket connection in any Peer object
     * gets a message/packet. The packet data is parsed and converted to
     * a Map object (packet_json). If it contains certain expected keys
     * the packet is either parsed by the signaling server or forwarded
     * to its destination Peer.
     * 
     * If the packet cant be converted to a Map object or if it doesnt
     * contain the expected keys the packet will be dropped.
     * @param {Websocket.MessageEvent} event
     */
    receive(event) {
        console.log("received packet")
        var packet = event.data
        var packet_json = try_parse_json(packet)

        console.log("\t" + packet)

        // if the packet valid
        if (packet_json != undefined) {
            console.log("\tpacket json valid")

            // if the packet contains the expected data
            if (packet_json.has("type") && packet_json.has("dst") && packet_json.has("src")) {
                console.log("\tpacket has type, dst and src")
                console.log("\ttype:", packet_json.get("type"), typeof(packet_json.get("type")), "\n\tdst:", packet_json.get("dst"), typeof(packet_json.get("dst")), "\n\tsrc:", packet_json.get("src"), typeof(packet_json.get("src")))

                // if packet destination is signaling server
                if (packet_json.get("dst") === -1) {
                    console.log("\tfor signaling server")
                    this.parse_packet(packet_json)
                }

                // if packet destination is a either a player or lobby peer
                else {
                    console.log("\tfor peer " + packet_json.get("dst"))
                    var dst_peer = this.get_peer(packet_json.get("dst"))
                    if (dst_peer != undefined) {
                        dst_peer.ws.send(packet)
                    }
                }
            }
        }
    }

    /**
     * Parse a packet who's destination is the signaling server
     * @param {Map} packet_json 
     */
    parse_packet(packet_json) {
        console.log("parsing packet")
        var src_peer = this.get_peer(packet_json.get("src"))

        switch (packet_json.get("type")) {

            case PacketTypes.DeclareLobbyHost:
                // The src has declared they wish to be a lobby host

                console.log("\tDeclaryLobbyHost")

                // gen the new lobby peer id
                var lobby_peer_id = this.gen_lobby_peer_id()
                
                // move the Peer object from the player_peers map to
                // the lobby_peers map
                this.lobby_peers.set(lobby_peer_id, src_peer)
                this.player_peers.delete(packet_json.get("src"))

                // update the peer object's id
                src_peer.id = lobby_peer_id
                this.send(PacketTypes.PeerAssignedID, lobby_peer_id)

                break
        }
    }


    /**
     * Helper function that generates a Number with PEER_ID_LEN
     * digits
     * @returns {number} */
    _gen_id() {
        var ID = ""
        for (let i = 0; i < PEER_ID_LEN; i++) {
            ID += NUM[~~(Math.random() * NUM.length)]
        }
        return Number(ID)
    }
    
    /**
     * Generate a unique peer id of type player. Eg. 12345678
     * @returns {number} ID
     */
    gen_player_peer_id() {
        var ID = this._gen_id()
        while (this.player_peers.has(ID)) {ID = this._gen_id()}
        return ID
    }

    /**
     * Generate a unique peer id of type lobby. Eg. L12345678
     * @returns {String}
     */
    gen_lobby_peer_id() {
        var ID = "L" + this._gen_id()
        while (this.lobby_peers.has(ID)) {ID = "L" + this._gen_id()}
        return ID
    }
}

/**
 * Try to parse text into a Map object
 * Returns a Map object on success, or undefined on failure
 * @param {string} text
 * @returns {undefined | Map}
 */
function try_parse_json(text) {
    try {
        var json = JSON.parse(text)
        return new Map(Object.entries(json))
    }
    catch {return undefined}
}


const peers = new Peers
const wss = new Websocket.Server({port: PORT})
console.log("Websocket server listening to", PORT)

wss.on("connection", (ws) => {
    console.log("new wss connection")
    peers.add_peer(ws)
})

wss.on("error", (err) => {
    console.error("WebSocket server error:", err)
})

// https://theodor-test-ced3867bc168.herokuapp.com/
